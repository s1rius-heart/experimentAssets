from __future__ import annotations

import sys
import unittest
from pathlib import Path


V6_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(V6_DIR))

import v6


class JobCoachAgentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.agent = v6.JobCoachAgent()

    def test_decision_recognizes_job_search_intents(self) -> None:
        cases = {
            "什么是STAR法则？": v6.Action.KNOWLEDGE_QA,
            "Python开发岗位需要什么技能？": v6.Action.JOB_ADVICE,
            "请帮我优化简历": v6.Action.RESUME_ADVICE,
            "请给这段面试回答打分：我负责了一个项目。": v6.Action.INTERVIEW_SCORING,
        }
        for text, expected_action in cases.items():
            with self.subTest(text=text):
                perception = self.agent.perception(text)
                decision = self.agent.decision(perception)
                self.assertEqual(decision.action, expected_action)

    def test_answers_job_search_knowledge_question(self) -> None:
        response = self.agent.handle("什么是STAR法则？")

        self.assertIn("情境Situation", response)
        self.assertIn("结果Result", response)

    def test_gives_role_and_resume_advice(self) -> None:
        role_response = self.agent.handle("Python开发岗位需要什么技能？")
        resume_response = self.agent.handle("请帮我优化简历")

        self.assertIn("Django/FastAPI", role_response)
        self.assertIn("简历建议", resume_response)
        self.assertIn("量化", resume_response)

    def test_scores_interview_answer_on_five_dimensions(self) -> None:
        response = self.agent.handle(
            "请给这段面试回答打分：当时项目进度落后，我负责重新制定目标。"
            "首先我分析了任务，然后通过自动化工具减少重复工作，"
            "最终将交付效率提升30%，按时完成项目。"
        )

        self.assertRegex(response, r"面试回答总分：\d+/100")
        self.assertIn("STAR结构", response)
        self.assertIn("量化证据", response)
        self.assertIn("岗位相关性", response)
        self.assertIn("表达清晰度", response)


if __name__ == "__main__":
    unittest.main()
