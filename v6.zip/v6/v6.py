from __future__ import annotations

import argparse
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# =============================================================
# V6: 求职知识大王
# - 沿用 V5 的“感知 -> 决策 -> 执行 -> 编排”结构。
# - 通过规则完成求职知识问答、岗位建议、简历建议和面试回答评分。
# =============================================================


@dataclass(frozen=True)
class RoleProfile:
    skills: tuple[str, ...]
    preparation: str


ROLE_PROFILES: dict[str, RoleProfile] = {
    "Python开发": RoleProfile(
        skills=("Python", "Django/FastAPI", "SQL", "Git"),
        preparation="准备一个可运行的后端项目，重点说明接口设计、数据库和性能优化。",
    ),
    "Java开发": RoleProfile(
        skills=("Java", "Spring Boot", "MySQL", "Redis"),
        preparation="准备一个分层清晰的服务端项目，熟悉JVM、并发和常用中间件。",
    ),
    "前端开发": RoleProfile(
        skills=("JavaScript/TypeScript", "Vue/React", "HTML/CSS", "性能优化"),
        preparation="准备可展示的页面或线上项目，说明组件设计、状态管理和用户体验改进。",
    ),
    "数据分析": RoleProfile(
        skills=("Excel", "SQL", "Python", "数据可视化"),
        preparation="准备一个从业务问题、数据清洗到结论落地的完整分析案例。",
    ),
    "产品经理": RoleProfile(
        skills=("需求分析", "原型设计", "数据分析", "沟通协作"),
        preparation="准备需求取舍和产品复盘案例，说清用户问题、决策依据和业务结果。",
    ),
    "测试工程师": RoleProfile(
        skills=("测试设计", "接口测试", "Python", "自动化测试"),
        preparation="准备缺陷定位和自动化提效案例，展示风险意识与质量思维。",
    ),
}

ROLE_ALIASES: dict[str, tuple[str, ...]] = {
    "Python开发": ("python", "Python开发", "后端"),
    "Java开发": ("java", "Java开发"),
    "前端开发": ("前端", "web前端"),
    "数据分析": ("数据分析", "数据分析师"),
    "产品经理": ("产品经理", "产品岗"),
    "测试工程师": ("测试工程师", "软件测试", "测试岗"),
}


# -----------------------------
# 感知（Perception）
# -----------------------------
@dataclass(frozen=True)
class PerceptionOutput:
    text: str
    tokens: list[str] = field(default_factory=list)


class Perception:
    def __call__(self, user_text: Optional[str]) -> PerceptionOutput:
        text = (user_text or "").strip()
        tokens = text.split() if text else []
        return PerceptionOutput(text=text, tokens=tokens)


# -----------------------------
# 决策（Decision）
# -----------------------------
class Action(str, Enum):
    KNOWLEDGE_QA = "knowledge_qa"
    JOB_ADVICE = "job_advice"
    RESUME_ADVICE = "resume_advice"
    INTERVIEW_SCORING = "interview_scoring"
    GREETING = "greeting"
    GENERAL = "general"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class DecisionOutput:
    action: Action


GREETING_KEYWORDS = ("你好", "嗨", "hello", "在吗")
SCORING_KEYWORDS = ("打分", "评分", "评价我的回答", "评估我的回答")
RESUME_KEYWORDS = ("简历", "项目经历", "工作经历", "个人优势")
JOB_KEYWORDS = ("岗位", "职位", "职业", "求职方向", "应聘", "适合什么工作")
QUESTION_KEYWORDS = ("怎么", "如何", "什么", "为什么", "怎么办", "请问", "介绍", "告诉我", "star")


class Decision:
    def __call__(self, perception: PerceptionOutput) -> DecisionOutput:
        text = perception.text
        if not text:
            return DecisionOutput(action=Action.UNKNOWN)

        normalized_text = text.lower()
        if any(keyword in normalized_text for keyword in SCORING_KEYWORDS):
            return DecisionOutput(action=Action.INTERVIEW_SCORING)
        if any(keyword in normalized_text for keyword in RESUME_KEYWORDS):
            return DecisionOutput(action=Action.RESUME_ADVICE)
        if any(keyword.lower() in normalized_text for keyword in JOB_KEYWORDS):
            return DecisionOutput(action=Action.JOB_ADVICE)

        is_question = normalized_text.endswith(("?", "？"))
        has_question_keyword = any(keyword in normalized_text for keyword in QUESTION_KEYWORDS)
        if is_question or has_question_keyword:
            return DecisionOutput(action=Action.KNOWLEDGE_QA)
        if any(keyword in normalized_text for keyword in GREETING_KEYWORDS):
            return DecisionOutput(action=Action.GREETING)
        return DecisionOutput(action=Action.GENERAL)


# -----------------------------
# 面试回答评分
# -----------------------------
@dataclass(frozen=True)
class InterviewScore:
    completeness: int
    star_structure: int
    evidence: int
    relevance: int
    clarity: int
    feedback: tuple[str, ...]

    @property
    def total(self) -> int:
        return self.completeness + self.star_structure + self.evidence + self.relevance + self.clarity


class InterviewScorer:
    STAR_CUE_GROUPS = (
        ("背景", "情境", "当时"),
        ("任务", "目标", "负责"),
        ("行动", "采取", "通过", "我先"),
        ("结果", "最终", "提升", "降低", "完成"),
    )

    def score(self, answer: str) -> InterviewScore:
        normalized_answer = answer.strip()
        completeness = self._score_completeness(normalized_answer)
        star_structure = sum(
            5 for cue_group in self.STAR_CUE_GROUPS
            if any(cue in normalized_answer for cue in cue_group)
        )
        evidence = self._score_evidence(normalized_answer)
        relevance = self._score_relevance(normalized_answer)
        clarity = self._score_clarity(normalized_answer)
        feedback = self._build_feedback(completeness, star_structure, evidence, relevance, clarity)
        return InterviewScore(completeness, star_structure, evidence, relevance, clarity, feedback)

    @staticmethod
    def _score_completeness(answer: str) -> int:
        if len(answer) >= 120:
            return 20
        if len(answer) >= 60:
            return 16
        if len(answer) >= 30:
            return 12
        return 6

    @staticmethod
    def _score_evidence(answer: str) -> int:
        quantified_result = re.search(
            r"\d+(?:\.\d+)?\s*(?:%|％|年|个月|万|次|人|项|天|小时)", answer
        )
        if quantified_result:
            return 20
        return 12 if re.search(r"\d", answer) else 5

    @staticmethod
    def _score_relevance(answer: str) -> int:
        relevance_keywords = ("岗位", "技能", "项目", "业务", "客户", "用户", "团队", "角色", "技术")
        return 20 if any(keyword in answer for keyword in relevance_keywords) else 10

    @staticmethod
    def _score_clarity(answer: str) -> int:
        score = 10
        if any(word in answer for word in ("首先", "其次", "然后", "最后", "因此")):
            score += 5
        punctuation_count = sum(answer.count(mark) for mark in "，。；！？,.!?")
        if 1 <= punctuation_count <= 12 and len(answer) <= 400:
            score += 5
        return score

    @staticmethod
    def _build_feedback(
        completeness: int,
        star_structure: int,
        evidence: int,
        relevance: int,
        clarity: int,
    ) -> tuple[str, ...]:
        suggestions: list[str] = []
        if completeness < 16:
            suggestions.append("补充问题背景、个人任务和最终结果。")
        if star_structure < 15:
            suggestions.append("按照STAR法则组织情境、任务、行动和结果。")
        if evidence < 20:
            suggestions.append("使用百分比、时间、人数或业务量等数据量化成果。")
        if relevance < 20:
            suggestions.append("突出与目标岗位相关的技能、职责和业务价值。")
        if clarity < 20:
            suggestions.append("使用“首先、然后、最后”等连接词提升表达条理。")
        if not suggestions:
            suggestions.append("回答结构和证据较完整，可继续压缩表达并强调个人贡献。")
        return tuple(suggestions)


# -----------------------------
# 执行（Execution）
# -----------------------------
class Executor:
    def __init__(self) -> None:
        self.interview_scorer = InterviewScorer()

    def __call__(self, decision: DecisionOutput, perception: PerceptionOutput) -> str:
        if decision.action == Action.KNOWLEDGE_QA:
            return self._answer_question(perception.text)
        if decision.action == Action.JOB_ADVICE:
            return self._advise_job(perception.text)
        if decision.action == Action.RESUME_ADVICE:
            return self._advise_resume(perception.text)
        if decision.action == Action.INTERVIEW_SCORING:
            return self._score_interview_answer(perception.text)
        if decision.action == Action.GREETING:
            return "你好，我是求职知识大王，可以陪你准备求职和面试。"
        if decision.action == Action.GENERAL:
            return self._general_help()
        return "请输入你的求职问题、目标岗位、简历内容或面试回答。"

    @staticmethod
    def _answer_question(text: str) -> str:
        normalized_text = text.lower()
        rules = (
            (("你是谁",), "我是求职知识大王，一个面向求职者的AI求职陪练系统。"),
            (("你能做什么",), "我能回答求职问题、提供岗位和简历建议，并对面试回答进行评分。"),
            (("star",), "STAR法则包括情境Situation、任务Task、行动Action和结果Result，适合用来结构化回答行为面试题。"),
            (("自我介绍",), "自我介绍建议控制在1至2分钟，按“背景、与岗位匹配的能力、代表成果、求职动机”展开。"),
            (("优点", "缺点", "优势", "劣势"), "回答优缺点时要给出具体事例。缺点应选择可改进项，并说明已采取的行动和进展。"),
            (("薪资", "期望薪资"), "回答期望薪资前先了解岗位和市场区间，给出合理范围，并表明愿结合职责和整体福利沟通。"),
            (("面试准备", "准备面试"), "面试前应研究岗位描述和公司业务，准备3个STAR项目案例，复习核心知识并进行模拟问答。"),
        )
        for keywords, answer in rules:
            if any(keyword in normalized_text for keyword in keywords):
                return answer
        return "这是一个求职知识问题。建议结合目标岗位、个人经历和具体场景进一步描述，我可以给出更有针对性的回答。"

    @staticmethod
    def _extract_role(text: str) -> Optional[str]:
        normalized_text = text.lower()
        for role, aliases in ROLE_ALIASES.items():
            if any(alias.lower() in normalized_text for alias in aliases):
                return role
        return None

    def _advise_job(self, text: str) -> str:
        role = self._extract_role(text)
        if role is None:
            return "岗位建议：先根据兴趣、已有技能和期望行业选择2至3个方向，再对照招聘要求统计高频技能。你可以告诉我专业、技能和意向岗位。"
        profile = ROLE_PROFILES[role]
        return f"{role}岗位建议：核心技能包括{'、'.join(profile.skills)}。{profile.preparation}"

    @staticmethod
    def _advise_resume(text: str) -> str:
        suggestions: list[str] = []
        if len(text) < 40:
            suggestions.append("提供目标岗位和主要经历，便于做针对性诊断")
        if not re.search(r"\d", text):
            suggestions.append("用数字量化业务规模、效率提升或项目成果")
        if not any(keyword in text for keyword in ("项目", "实习", "工作经历")):
            suggestions.append("补充最能体现岗位能力的项目或实习经历")
        if not any(keyword in text.lower() for keyword in ("技能", "python", "java", "sql", "excel")):
            suggestions.append("在简历中显式列出与职位描述匹配的核心技能")
        if not suggestions:
            suggestions.append("按与目标岗位的相关性排序经历，每条内容使用“行动+结果”表达")
        return "简历建议：" + "；".join(suggestions) + "。"

    def _score_interview_answer(self, text: str) -> str:
        answer = self._extract_interview_answer(text)
        if not answer:
            return "请在“请给这段面试回答打分：”后面附上完整回答。"
        score = self.interview_scorer.score(answer)
        feedback = "；".join(score.feedback)
        return (
            f"面试回答总分：{score.total}/100\n"
            f"完整度：{score.completeness}/20，STAR结构：{score.star_structure}/20，"
            f"量化证据：{score.evidence}/20，岗位相关性：{score.relevance}/20，"
            f"表达清晰度：{score.clarity}/20\n改进建议：{feedback}"
        )

    @staticmethod
    def _extract_interview_answer(text: str) -> str:
        if "：" in text or ":" in text:
            parts = re.split(r"[：:]", text, maxsplit=1)
            if len(parts) == 2 and any(keyword in parts[0] for keyword in SCORING_KEYWORDS):
                return parts[1].strip()
        match = re.search(r"(?:打分|评分)[，,。.\s]*(.+)$", text)
        return match.group(1).strip() if match else ""

    @staticmethod
    def _general_help() -> str:
        return "我可以回答求职知识、提供岗位或简历建议，也可以对你的面试回答进行百分制打分。"


# -----------------------------
# 编排器与主入口
# -----------------------------
class JobCoachAgent:
    def __init__(self) -> None:
        self.perception = Perception()
        self.decision = Decision()
        self.executor = Executor()

    def handle(self, user_text: Optional[str]) -> str:
        perception = self.perception(user_text)
        decision = self.decision(perception)
        return self.executor(decision, perception)


def main() -> None:
    parser = argparse.ArgumentParser(description="Job Knowledge King V6 (No LLM)")
    parser.parse_args()

    agent = JobCoachAgent()
    print("=================================================")
    print("求职知识大王（V6）已启动。")
    print("可用功能：1. 求职知识问答 2. 岗位建议 3. 简历建议 4. 面试回答打分")
    print("=================================================")

    while True:
        try:
            user_input = input("用户: ")
            if user_input.strip():
                print(f"助手: {agent.handle(user_input)}")
        except (EOFError, KeyboardInterrupt):
            print("\n感谢使用，祝你求职顺利！")
            break


if __name__ == "__main__":
    main()
